import '../models/waste_point.dart';

/// Coordenadas de referência para a região de estudo: Riacho Fundo I, DF.
class AppConstants {
  static const double riachoFundoLat = -15.8824;
  static const double riachoFundoLng = -47.9942;
  static const String appName = 'EcoMapa DF';
  static const String appSubtitle = 'Mapeando resíduos. Construindo soluções.';
}

/// Categorias padronizadas de materiais conforme Ciência dos Materiais
class MaterialCategories {
  static const List<String> list = [
    'Plástico',
    'Vidro',
    'Metal',
    'Papel/Papelão',
    'Madeira',
    'Resíduo de construção',
    'Resíduo eletrônico',
    'Resíduo orgânico',
    'Têxtil',
    'Borracha',
    'Resíduo misto',
    'Outro',
  ];

  static const List<String> pointTypes = [
    'Descarte irregular',
    'Ponto adequado',
    'Ecoponto',
    'Outro',
  ];

  static const List<String> mixedOptions = [
    'Sim',
    'Não',
    'Não identificado',
  ];
}

/// Registros de demonstração georreferenciados em Riacho Fundo I.
/// Claramente etiquetados com [DADOS DE DEMONSTRAÇÃO].
List<WastePoint> getInitialDemoPoints() {
  return [
    WastePoint(
      id: 'demo-1',
      latitude: -15.8845,
      longitude: -47.9965,
      tipoPonto: 'Descarte irregular',
      categoriaResiduo: 'Resíduo de construção',
      materialPredominante: 'Resíduo de construção',
      residuoMisto: 'Sim',
      observacao:
          '[DADOS DE DEMONSTRAÇÃO] Entulho de reforma residencial com sacos plásticos na margem da via vicinal.',
      dataHora: DateTime.now().subtract(const Duration(days: 2)),
      status: 'validado',
      isDemo: true,
    ),
    WastePoint(
      id: 'demo-2',
      latitude: -15.8812,
      longitude: -47.9928,
      tipoPonto: 'Ecoponto',
      categoriaResiduo: 'Resíduo eletrônico',
      materialPredominante: 'Metal',
      residuoMisto: 'Não',
      observacao:
          '[DADOS DE DEMONSTRAÇÃO] Ponto de Entrega Voluntária com descarte adequado de monitores e placas eletrônicas.',
      dataHora: DateTime.now().subtract(const Duration(days: 3)),
      status: 'validado',
      isDemo: true,
    ),
    WastePoint(
      id: 'demo-3',
      latitude: -15.8890,
      longitude: -48.0012,
      tipoPonto: 'Descarte irregular',
      categoriaResiduo: 'Plástico',
      materialPredominante: 'Plástico',
      residuoMisto: 'Sim',
      observacao:
          '[DADOS DE DEMONSTRAÇÃO] Garrafas PET, sacolas e embalagens descartadas em lote vago próximo à QN 5.',
      dataHora: DateTime.now().subtract(const Duration(days: 1)),
      status: 'pendente',
      isDemo: true,
    ),
    WastePoint(
      id: 'demo-4',
      latitude: -15.8785,
      longitude: -47.9978,
      tipoPonto: 'Ponto adequado',
      categoriaResiduo: 'Vidro',
      materialPredominante: 'Vidro',
      residuoMisto: 'Não',
      observacao:
          '[DADOS DE DEMONSTRAÇÃO] Coletor comunitário para garrafas de vidro e frascos íntegros.',
      dataHora: DateTime.now().subtract(const Duration(hours: 12)),
      status: 'validado',
      isDemo: true,
    ),
    WastePoint(
      id: 'demo-5',
      latitude: -15.8860,
      longitude: -48.0040,
      tipoPonto: 'Descarte irregular',
      categoriaResiduo: 'Madeira',
      materialPredominante: 'Madeira',
      residuoMisto: 'Sim',
      observacao:
          '[DADOS DE DEMONSTRAÇÃO] Móveis desmontados e restos de compensado abandonados na calçada.',
      dataHora: DateTime.now().subtract(const Duration(hours: 4)),
      status: 'pendente',
      isDemo: true,
    ),
  ];
}

/// Modelo simples para Ecopontos oficiais / Papa-Entulho no DF.
class EcopointModel {
  final String nome;
  final String endereco;
  final String regiao;
  final List<String> materiais;
  final String horario;
  final double distanciaKm;

  const EcopointModel({
    required this.nome,
    required this.endereco,
    required this.regiao,
    required this.materiais,
    required this.horario,
    required this.distanciaKm,
  });
}

/// Lista de demonstração de Ecopontos (Papa-Entulho SLU) em Riacho Fundo e regiões vizinhas.
/// Local indicado no código para plugar futuramente a API oficial do SLU DF.
const List<EcopointModel> demoEcopointsList = [
  EcopointModel(
    nome: 'Papa-Entulho SLU - Riacho Fundo I',
    endereco: 'QN 7, Área Especial 01, Riacho Fundo I, DF',
    regiao: 'Riacho Fundo I',
    materiais: [
      'Entulho de alvenaria e obra (até 1m³)',
      'Madeira e móveis desmontados',
      'Podas de árvores e galhos',
      'Materiais recicláveis secos (plástico, papel, metal, vidro)'
    ],
    horario: 'Segunda a Sábado: 07h00 às 18h00',
    distanciaKm: 0.7,
  ),
  EcopointModel(
    nome: 'Papa-Entulho SLU - Riacho Fundo II',
    endereco: 'QN 14E, Lote 01, Riacho Fundo II, DF',
    regiao: 'Riacho Fundo II',
    materiais: [
      'Restos de reformas residenciais',
      'Mobiliário inservível',
      'Pneus e recicláveis secos'
    ],
    horario: 'Segunda a Sábado: 07h00 às 18h00',
    distanciaKm: 3.2,
  ),
  EcopointModel(
    nome: 'Papa-Entulho SLU - Núcleo Bandeirante',
    endereco: 'Setor de Oficinas, Conjunto A, Núcleo Bandeirante, DF',
    regiao: 'Núcleo Bandeirante',
    materiais: [
      'Resíduos volumosos',
      'Entulho da construção civil',
      'Metais e plásticos'
    ],
    horario: 'Segunda a Sábado: 07h00 às 18h00',
    distanciaKm: 4.1,
  ),
  EcopointModel(
    nome: 'Ponto de Coleta Voluntária - Praça Central RF1',
    endereco: 'Área Central, Riacho Fundo I (Próximo à Feira Permanente)',
    regiao: 'Riacho Fundo I',
    materiais: [
      'Garrafas PET e plásticos',
      'Papel e papelão',
      'Latas de alumínio',
      'Vidros limpos'
    ],
    horario: 'Acesso livre 24 horas',
    distanciaKm: 0.9,
  ),
];
