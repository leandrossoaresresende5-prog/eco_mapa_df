import 'dart:convert';

/// Modelo de dados representando um ponto registrado no EcoMapa DF.
/// Conecta a identificação de campo à Ciência e Engenharia de Materiais.
class WastePoint {
  final String id;
  final double latitude;
  final double longitude;
  final String tipoPonto; // 'Descarte irregular', 'Ponto adequado', 'Ecoponto', 'Outro'
  final String categoriaResiduo; // 'Plástico', 'Vidro', 'Metal', etc.
  final String materialPredominante;
  final String residuoMisto; // 'Sim', 'Não', 'Não identificado'
  final String? imagem; // Caminho local do arquivo ou base64
  final String observacao;
  final DateTime dataHora;
  final String status; // 'pendente', 'validado', 'rejeitado'
  final bool isDemo; // Identifica dados de demonstração com clareza

  WastePoint({
    required this.id,
    required this.latitude,
    required this.longitude,
    required this.tipoPonto,
    required this.categoriaResiduo,
    required this.materialPredominante,
    required this.residuoMisto,
    this.imagem,
    required this.observacao,
    required this.dataHora,
    this.status = 'pendente',
    this.isDemo = false,
  });

  /// Converte o objeto para Map serializável em JSON
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'latitude': latitude,
      'longitude': longitude,
      'tipoPonto': tipoPonto,
      'categoriaResiduo': categoriaResiduo,
      'materialPredominante': materialPredominante,
      'residuoMisto': residuoMisto,
      'imagem': imagem,
      'observacao': observacao,
      'dataHora': dataHora.toIso8601String(),
      'status': status,
      'isDemo': isDemo,
    };
  }

  /// Cria uma instância a partir de um Map decodificado de JSON
  factory WastePoint.fromMap(Map<String, dynamic> map) {
    return WastePoint(
      id: map['id'] ?? '',
      latitude: (map['latitude'] as num).toDouble(),
      longitude: (map['longitude'] as num).toDouble(),
      tipoPonto: map['tipoPonto'] ?? 'Descarte irregular',
      categoriaResiduo: map['categoriaResiduo'] ?? 'Outro',
      materialPredominante: map['materialPredominante'] ?? 'Outro',
      residuoMisto: map['residuoMisto'] ?? 'Não identificado',
      imagem: map['imagem'],
      observacao: map['observacao'] ?? '',
      dataHora: map['dataHora'] != null
          ? DateTime.parse(map['dataHora'])
          : DateTime.now(),
      status: map['status'] ?? 'pendente',
      isDemo: map['isDemo'] ?? false,
    );
  }

  String toJson() => json.encode(toMap());

  factory WastePoint.fromJson(String source) =>
      WastePoint.fromMap(json.decode(source));

  WastePoint copyWith({
    String? id,
    double? latitude,
    double? longitude,
    String? tipoPonto,
    String? categoriaResiduo,
    String? materialPredominante,
    String? residuoMisto,
    String? imagem,
    String? observacao,
    DateTime? dataHora,
    String? status,
    bool? isDemo,
  }) {
    return WastePoint(
      id: id ?? this.id,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      tipoPonto: tipoPonto ?? this.tipoPonto,
      categoriaResiduo: categoriaResiduo ?? this.categoriaResiduo,
      materialPredominante: materialPredominante ?? this.materialPredominante,
      residuoMisto: residuoMisto ?? this.residuoMisto,
      imagem: imagem ?? this.imagem,
      observacao: observacao ?? this.observacao,
      dataHora: dataHora ?? this.dataHora,
      status: status ?? this.status,
      isDemo: isDemo ?? this.isDemo,
    );
  }
}
