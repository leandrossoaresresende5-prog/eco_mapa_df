import 'package:flutter/material.dart';

/// Tela explicativa sobre o projeto EcoMapa DF
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sobre o Projeto'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.science, color: Color(0xFF1B5E20), size: 36),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'O EcoMapa DF é uma iniciativa de ciência cidadã voltada ao registro e monitoramento de pontos de descarte de resíduos.',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF1B5E20),
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            const Text(
              'Objetivos da Iniciativa',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 12),
            _buildGoalItem(
              Icons.school_outlined,
              'Contribuir para a educação ambiental e conscientização urbana.',
            ),
            _buildGoalItem(
              Icons.pin_drop_outlined,
              'Gerar dados georreferenciados precisos para planejamento público.',
            ),
            _buildGoalItem(
              Icons.analytics_outlined,
              'Identificar padrões espaciais e temporais de descarte irregular.',
            ),
            _buildGoalItem(
              Icons.category_outlined,
              'Estudar a ocorrência e persistência de diferentes classes de materiais.',
            ),
            _buildGoalItem(
              Icons.handshake_outlined,
              'Apoiar ações ambientais locais e organizações comunitárias.',
            ),
            _buildGoalItem(
              Icons.devices_other_outlined,
              'Aproximar tecnologia, pesquisa científica e comunidade.',
            ),

            const SizedBox(height: 24),
            const Text(
              'Área Piloto de Estudo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: const Text(
                'A primeira região de atuação e validação metodológica é a Região Administrativa do Riacho Fundo I (DF). Com o avanço das coletas comunitárias, a malha de monitoramento será expandida para outras regiões do Distrito Federal.',
                style: TextStyle(fontSize: 14, color: Color(0xFF334155), height: 1.5),
              ),
            ),

            const SizedBox(height: 24),
            const Text(
              'Conexão com Ciência dos Materiais',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: const Text(
                'A classificação de materiais (polímeros, metais, cerâmicos/construção civil, vidros, celulose) permite compreender os ciclos de vida, degradabilidade e viabilidade de reciclagem ou reuso, fundamentando políticas sustentáveis no DF.',
                style: TextStyle(fontSize: 14, color: Color(0xFF334155), height: 1.5),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildGoalItem(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F5F9),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 20, color: const Color(0xFF2E7D32)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14, color: Color(0xFF334155)),
            ),
          ),
        ],
      ),
    );
  }
}
