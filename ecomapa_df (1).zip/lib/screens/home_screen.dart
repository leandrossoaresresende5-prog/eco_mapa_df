import 'package:flutter/material.dart';
import 'about_screen.dart';
import 'ecopoints_screen.dart';

/// Tela Inicial do EcoMapa DF
class HomeScreen extends StatelessWidget {
  final Function(int) onNavigateToTab;

  const HomeScreen({
    super.key,
    required this.onNavigateToTab,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.eco, color: Color(0xFF2E7D32)),
            SizedBox(width: 8),
            Text(
              'EcoMapa DF',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'Sobre o projeto',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AboutScreen()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Banner de Identidade Visual
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1B5E20), Color(0xFF2E7D32)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF2E7D32).withOpacity(0.25),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'CIÊNCIA CIDADÃ • RIACHO FUNDO I',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'EcoMapa DF',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Mapeando resíduos. Construindo soluções.',
                    style: TextStyle(
                      color: Color(0xFFE8F5E9),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Ajude a identificar, registrar e monitorar pontos de descarte de resíduos no Distrito Federal. Conecte dados de campo à Ciência e Engenharia de Materiais.',
                    style: TextStyle(
                      color: Color(0xFFC8E6C9),
                      fontSize: 13,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            const Text(
              'Acesso Rápido',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 14),

            // Botão 1: Ver Mapa
            _buildActionCard(
              title: 'Ver mapa',
              subtitle: 'Visualize pontos de descarte e ecopontos no mapa',
              icon: Icons.map_outlined,
              color: const Color(0xFF2E7D32),
              onTap: () => onNavigateToTab(1), // Aba Mapa
            ),
            const SizedBox(height: 12),

            // Botão 2: Registrar Ponto
            _buildActionCard(
              title: 'Registrar ponto',
              subtitle: 'Georreferencie e classifique resíduos com fotos',
              icon: Icons.add_location_alt_outlined,
              color: const Color(0xFF15803D),
              onTap: () => onNavigateToTab(2), // Aba Registrar
            ),
            const SizedBox(height: 12),

            // Botão 3: Ecopontos
            _buildActionCard(
              title: 'Ecopontos',
              subtitle: 'Locais adequados de descarte e Papa-Entulho no DF',
              icon: Icons.recycling_outlined,
              color: const Color(0xFF0284C7),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const EcopointsScreen()),
                );
              },
            ),
            const SizedBox(height: 12),

            // Botão 4: Estatísticas
            _buildActionCard(
              title: 'Estatísticas',
              subtitle: 'Gráficos por categoria de material e descarte',
              icon: Icons.bar_chart_outlined,
              color: const Color(0xFFD97706),
              onTap: () => onNavigateToTab(3), // Aba Estatísticas
            ),
            const SizedBox(height: 12),

            // Botão 5: Sobre o Projeto
            _buildActionCard(
              title: 'Sobre o projeto',
              subtitle: 'Objetivos científicos e impacto comunitário',
              icon: Icons.menu_book_outlined,
              color: const Color(0xFF475569),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AboutScreen()),
                );
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 26),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios,
                  size: 16, color: Color(0xFF94A3B8)),
            ],
          ),
        ),
      ),
    );
  }
}
