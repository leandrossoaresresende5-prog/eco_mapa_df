import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../models/waste_point.dart';
import '../services/storage_service.dart';
import '../services/location_service.dart';
import '../data/demo_data.dart';
import 'package:intl/intl.dart';

/// Tela do Mapa com marcadores georreferenciados
class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController _mapController = MapController();
  List<WastePoint> _points = [];
  bool _isLoading = true;
  LatLng _currentCenter = const LatLng(AppConstants.riachoFundoLat, AppConstants.riachoFundoLng);
  LatLng? _userPosition;

  @override
  void initState() {
    super.initState();
    _loadPoints();
  }

  Future<void> _loadPoints() async {
    setState(() => _isLoading = true);
    final points = await StorageService.loadWastePoints();
    setState(() {
      _points = points;
      _isLoading = false;
    });
  }

  Future<void> _goToUserLocation() async {
    final result = await LocationService.getCurrentLocation();
    if (!mounted) return;

    if (result.isSuccess && result.position != null) {
      final userLatLng = LatLng(
        result.position!.latitude,
        result.position!.longitude,
      );
      setState(() {
        _userPosition = userLatLng;
      });
      _mapController.move(userLatLng, 15.0);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Localização obtida com sucesso!'),
          backgroundColor: Color(0xFF2E7D32),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result.errorMessage ?? 'Não foi possível obter localização.'),
          backgroundColor: const Color(0xFFD32F2F),
        ),
      );
    }
  }

  Color _getMarkerColor(WastePoint point) {
    if (point.tipoPonto == 'Ecoponto' || point.tipoPonto == 'Ponto adequado') {
      return const Color(0xFF2E7D32); // VERDE: Ponto adequado / ecoponto
    } else if (point.tipoPonto == 'Descarte irregular') {
      return const Color(0xFFD32F2F); // VERMELHO: Descarte irregular
    } else {
      return const Color(0xFFF57C00); // AMARELO/LARANJA: Ponto aguardando verificação
    }
  }

  void _showPointDetails(WastePoint point) {
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm');
    final color = _getMarkerColor(point);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              if (point.isDemo)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFEF3C7),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'DADO DE DEMONSTRAÇÃO (EXEMPLO)',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF92400E),
                    ),
                  ),
                ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.location_on, color: color, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          point.tipoPonto,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: color,
                          ),
                        ),
                        Text(
                          'Status: ${point.status.toUpperCase()}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 24),
              _detailRow('Categoria do resíduo:', point.categoriaResiduo),
              _detailRow('Material predominante:', point.materialPredominante),
              _detailRow('Resíduo misto?', point.residuoMisto),
              _detailRow('Data e hora:', dateFormat.format(point.dataHora)),
              _detailRow('Coordenadas:', '${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}'),
              const SizedBox(height: 10),
              const Text(
                'Observação:',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Text(
                point.observacao.isEmpty ? 'Sem observações adicionais.' : point.observacao,
                style: const TextStyle(fontSize: 13, color: Color(0xFF334155)),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 160,
            child: Text(
              label,
              style: const TextStyle(fontSize: 13, color: Color(0xFF64748B)),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Color(0xFF0F172A),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa de Resíduos (DF)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Atualizar pontos',
            onPressed: _loadPoints,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: _currentCenter,
                    initialZoom: 14.5,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'com.ecomapa.df',
                    ),
                    MarkerLayer(
                      markers: [
                        // Marcador da posição atual do usuário (se obtida)
                        if (_userPosition != null)
                          Marker(
                            point: _userPosition!,
                            width: 50,
                            height: 50,
                            child: const Icon(
                              Icons.my_location,
                              color: Colors.blueAccent,
                              size: 32,
                            ),
                          ),
                        // Marcadores de descarte
                        ..._points.map((p) {
                          final color = _getMarkerColor(p);
                          return Marker(
                            point: LatLng(p.latitude, p.longitude),
                            width: 44,
                            height: 44,
                            child: GestureDetector(
                              onTap: () => _showPointDetails(p),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: color,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 2.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 6,
                                      offset: const Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.delete_outline,
                                  color: Colors.white,
                                  size: 22,
                                ),
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ],
                ),

                // Legenda flutuante no topo
                Positioned(
                  top: 12,
                  left: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.95),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _legendItem('Adequado', const Color(0xFF2E7D32)),
                        _legendItem('Irregular', const Color(0xFFD32F2F)),
                        _legendItem('Em análise', const Color(0xFFF57C00)),
                      ],
                    ),
                  ),
                ),

                // Botão flutuante para centralizar no GPS
                Positioned(
                  bottom: 20,
                  right: 16,
                  child: FloatingActionButton.extended(
                    heroTag: 'map_gps_btn',
                    onPressed: _goToUserLocation,
                    backgroundColor: const Color(0xFF2E7D32),
                    icon: const Icon(Icons.my_location, color: Colors.white),
                    label: const Text(
                      'Minha Posição',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _legendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
