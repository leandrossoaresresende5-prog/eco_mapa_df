import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../models/waste_point.dart';
import '../services/location_service.dart';
import '../services/storage_service.dart';
import '../data/demo_data.dart';

/// Tela "Registrar ponto"
class RegisterScreen extends StatefulWidget {
  final VoidCallback? onPointSaved;

  const RegisterScreen({super.key, this.onPointSaved});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _obsController = TextEditingController();

  // Estados dos campos
  String _selectedTipoPonto = 'Descarte irregular';
  String _selectedCategoria = 'Plástico';
  String _selectedMaterialPredominante = 'Plástico';
  String _selectedResiduoMisto = 'Não identificado';

  double? _latitude;
  double? _longitude;
  bool _isLoadingGps = false;
  String? _gpsStatusMessage;

  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  bool _isSaving = false;

  @override
  void dispose() {
    _obsController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: source,
        maxWidth: 1200,
        imageQuality: 80,
      );
      if (picked != null) {
        setState(() {
          _imageFile = File(picked.path);
        });
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Não foi possível carregar a imagem: ${e.toString()}'),
          backgroundColor: const Color(0xFFD32F2F),
        ),
      );
    }
  }

  Future<void> _getLocation() async {
    setState(() {
      _isLoadingGps = true;
      _gpsStatusMessage = null;
    });

    final result = await LocationService.getCurrentLocation();

    if (!mounted) return;
    setState(() {
      _isLoadingGps = false;
      if (result.isSuccess && result.position != null) {
        _latitude = result.position!.latitude;
        _longitude = result.position!.longitude;
        _gpsStatusMessage = 'Localização obtida com sucesso!';
      } else {
        _gpsStatusMessage = result.errorMessage ?? 'Erro ao obter localização.';
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_gpsStatusMessage!),
        backgroundColor:
            result.isSuccess ? const Color(0xFF2E7D32) : const Color(0xFFD32F2F),
      ),
    );
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Adicionar Fotografia',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.camera_alt, color: Color(0xFF2E7D32)),
                  title: const Text('Tirar fotografia pela câmera'),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.photo_library, color: Color(0xFF2E7D32)),
                  title: const Text('Selecionar imagem da galeria'),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _savePoint() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_latitude == null || _longitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Por favor, obtenha a localização GPS antes de salvar o ponto.',
          ),
          backgroundColor: Color(0xFFD32F2F),
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    final newPoint = WastePoint(
      id: 'point-${DateTime.now().millisecondsSinceEpoch}',
      latitude: _latitude!,
      longitude: _longitude!,
      tipoPonto: _selectedTipoPonto,
      categoriaResiduo: _selectedCategoria,
      materialPredominante: _selectedMaterialPredominante,
      residuoMisto: _selectedResiduoMisto,
      imagem: _imageFile?.path,
      observacao: _obsController.text.trim(),
      dataHora: DateTime.now(),
      status: 'pendente',
      isDemo: false,
    );

    final success = await StorageService.addWastePoint(newPoint);

    if (!mounted) return;
    setState(() => _isSaving = false);

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ponto salvo com sucesso no EcoMapa DF!'),
          backgroundColor: Color(0xFF2E7D32),
        ),
      );
      // Limpa formulário
      setState(() {
        _latitude = null;
        _longitude = null;
        _imageFile = null;
        _obsController.clear();
        _selectedTipoPonto = 'Descarte irregular';
        _selectedCategoria = 'Plástico';
        _selectedMaterialPredominante = 'Plástico';
        _selectedResiduoMisto = 'Não identificado';
        _gpsStatusMessage = null;
      });
      widget.onPointSaved?.call();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Falha ao salvar o ponto. Tente novamente.'),
          backgroundColor: Color(0xFFD32F2F),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Registrar Ponto'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. TIPO DO PONTO
              _buildSectionTitle('1. Tipo do Ponto'),
              DropdownButtonFormField<String>(
                value: _selectedTipoPonto,
                decoration: _inputDecoration('Selecione o tipo do ponto'),
                items: MaterialCategories.pointTypes.map((t) {
                  return DropdownMenuItem(value: t, child: Text(t));
                }).toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedTipoPonto = val);
                },
              ),
              const SizedBox(height: 20),

              // 2. CATEGORIA DO RESÍDUO
              _buildSectionTitle('2. Categoria do Resíduo'),
              DropdownButtonFormField<String>(
                value: _selectedCategoria,
                decoration: _inputDecoration('Categoria geral'),
                items: MaterialCategories.list.map((c) {
                  return DropdownMenuItem(value: c, child: Text(c));
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() {
                      _selectedCategoria = val;
                      _selectedMaterialPredominante = val;
                    });
                  }
                },
              ),
              const SizedBox(height: 20),

              // 3. MATERIAL PREDOMINANTE (Ciência dos Materiais)
              _buildSectionTitle('3. Material Predominante (Ciência dos Materiais)'),
              const Text(
                'Classifique o material com maior volume ou peso na amostra de descarte.',
                style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedMaterialPredominante,
                decoration: _inputDecoration('Material predominante'),
                items: MaterialCategories.list.map((m) {
                  return DropdownMenuItem(value: m, child: Text(m));
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() => _selectedMaterialPredominante = val);
                  }
                },
              ),
              const SizedBox(height: 20),

              // 4. RESÍDUO MISTO
              _buildSectionTitle('4. É resíduo misto?'),
              Row(
                children: MaterialCategories.mixedOptions.map((opt) {
                  final isSelected = _selectedResiduoMisto == opt;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(opt),
                        selected: isSelected,
                        selectedColor: const Color(0xFFE8F5E9),
                        labelStyle: TextStyle(
                          color: isSelected
                              ? const Color(0xFF1B5E20)
                              : const Color(0xFF475569),
                          fontWeight:
                              isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                        onSelected: (selected) {
                          if (selected) {
                            setState(() => _selectedResiduoMisto = opt);
                          }
                        },
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),

              // 5. FOTOGRAFIA
              _buildSectionTitle('5. Fotografia do Descarte'),
              if (_imageFile != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    _imageFile!,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      label: const Text('Remover foto',
                          style: TextStyle(color: Colors.red)),
                      onPressed: () => setState(() => _imageFile = null),
                    ),
                  ],
                ),
              ] else
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const Icon(Icons.add_a_photo_outlined,
                      color: Color(0xFF2E7D32)),
                  label: const Text(
                    'Adicionar fotografia',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF2E7D32),
                    ),
                  ),
                  onPressed: _showImageSourceDialog,
                ),
              const SizedBox(height: 20),

              // 6. LOCALIZAÇÃO GPS
              _buildSectionTitle('6. Localização GPS'),
              if (_latitude != null && _longitude != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8F5E9),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFFA5D6A7)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle,
                          color: Color(0xFF2E7D32), size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Lat: ${_latitude!.toStringAsFixed(5)}, Lng: ${_longitude!.toStringAsFixed(5)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1B5E20),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: _isLoadingGps
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.my_location, color: Color(0xFF2E7D32)),
                label: Text(
                  _isLoadingGps
                      ? 'Obtendo GPS...'
                      : (_latitude == null
                          ? 'Obter minha localização'
                          : 'Atualizar localização GPS'),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2E7D32),
                  ),
                ),
                onPressed: _isLoadingGps ? null : _getLocation,
              ),
              const SizedBox(height: 20),

              // 7. OBSERVAÇÃO
              _buildSectionTitle('7. Observação Livre'),
              TextFormField(
                controller: _obsController,
                maxLines: 3,
                decoration: _inputDecoration(
                  'Descreva o estado do material, volume aproximado, pontos de referência...',
                ),
              ),
              const SizedBox(height: 20),

              // 8. DATA E HORA
              _buildSectionTitle('8. Data e Hora'),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF1F5F9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today_outlined,
                        size: 18, color: Color(0xFF64748B)),
                    const SizedBox(width: 10),
                    Text(
                      'Preenchido automaticamente: ${dateFormat.format(DateTime.now())}',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Color(0xFF475569),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),

              // BOTÃO SALVAR
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF2E7D32),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: _isSaving ? null : _savePoint,
                child: _isSaving
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        'Salvar ponto',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.bold,
          color: Color(0xFF0F172A),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF2E7D32), width: 1.5),
      ),
    );
  }
}
