import 'package:flutter/material.dart';
import '../models/waste_point.dart';
import '../services/storage_service.dart';
import '../widgets/statistic_card.dart';

/// Tela de Estatísticas do EcoMapa DF
class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  List<WastePoint> _points = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final list = await StorageService.loadWastePoints();
    setState(() {
      _points = list;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Cálculos estatísticos em tempo real
    final int total = _points.length;
    final int irregularCount =
        _points.where((p) => p.tipoPonto == 'Descarte irregular').length;
    final int adequateCount = _points
        .where((p) => p.tipoPonto == 'Ponto adequado' || p.tipoPonto == 'Ecoponto')
        .length;
    final int mixedCount = _points.where((p) => p.residuoMisto == 'Sim').length;

    // Contagem por categoria de material predominante
    final Map<String, int> materialCount = {};
    for (var p in _points) {
      final mat = p.materialPredominante;
      materialCount[mat] = (materialCount[mat] ?? 0) + 1;
    }

    // Ordena materiais por maior frequência
    final sortedMaterials = materialCount.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Estatísticas dos Registros'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resumo Geral',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Cards de métricas principais em Grid
                  Row(
                    children: [
                      Expanded(
                        child: MetricCard(
                          title: 'Total de Registros',
                          value: total.toString(),
                          icon: Icons.assignment_outlined,
                          color: const Color(0xFF2E7D32),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: MetricCard(
                          title: 'Descartes Irregulares',
                          value: irregularCount.toString(),
                          icon: Icons.warning_amber_rounded,
                          color: const Color(0xFFD32F2F),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: MetricCard(
                          title: 'Pontos Adequados',
                          value: adequateCount.toString(),
                          icon: Icons.check_circle_outline,
                          color: const Color(0xFF0284C7),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: MetricCard(
                          title: 'Resíduos Mistos',
                          value: mixedCount.toString(),
                          icon: Icons.layers_outlined,
                          color: const Color(0xFFD97706),
                          subtitle: total > 0
                              ? '${((mixedCount / total) * 100).round()}% do total'
                              : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // Gráfico de Materiais Encontrados (Ciência dos Materiais)
                  const Text(
                    'Materiais Predominantes Encontrados',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Análise de frequência de categorias para caracterização de impacto e reciclagem.',
                    style: TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                  ),
                  const SizedBox(height: 16),

                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: Colors.grey.shade200),
                    ),
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: sortedMaterials.isEmpty
                          ? const Center(
                              child: Text('Nenhum registro encontrado.'),
                            )
                          : Column(
                              children: sortedMaterials.map((entry) {
                                return MaterialBarItem(
                                  label: entry.key,
                                  count: entry.value,
                                  total: total,
                                  color: _getColorForMaterial(entry.key),
                                );
                              }).toList(),
                            ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }

  Color _getColorForMaterial(String material) {
    switch (material) {
      case 'Plástico':
        return const Color(0xFF2563EB); // Azul
      case 'Resíduo de construção':
        return const Color(0xFF78350F); // Marrom escuro
      case 'Vidro':
        return const Color(0xFF0D9488); // Verde petróleo
      case 'Metal':
        return const Color(0xFF64748B); // Aço / Cinza
      case 'Papel/Papelão':
        return const Color(0xFFD97706); // Âmbar
      case 'Madeira':
        return const Color(0xFFB45309);
      case 'Resíduo eletrônico':
        return const Color(0xFF7C3AED); // Roxo
      case 'Resíduo orgânico':
        return const Color(0xFF15803D); // Verde folha
      default:
        return const Color(0xFF2E7D32);
    }
  }
}
