import 'package:geolocator/geolocator.dart';

/// Resultado encapsulado da tentativa de obter localização GPS.
class LocationResult {
  final Position? position;
  final String? errorMessage;
  final bool isSuccess;

  LocationResult.success(this.position)
      : errorMessage = null,
        isSuccess = true;

  LocationResult.error(this.errorMessage)
      : position = null,
        isSuccess = false;
}

/// Serviço responsável por interagir com o GPS do dispositivo Android de forma segura.
class LocationService {
  /// Obtém a posição GPS atual, tratando todas as exceções e permissões sem fechar o app.
  static Future<LocationResult> getCurrentLocation() async {
    try {
      // 1. Verifica se o serviço de GPS do aparelho está ativo
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return LocationResult.error(
          'O GPS do seu celular está desativado. Por favor, ative a localização nas configurações do Android.',
        );
      }

      // 2. Verifica a permissão concedida pelo usuário
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return LocationResult.error(
            'Permissão de localização negada pelo usuário. Não foi possível obter o georreferenciamento.',
          );
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return LocationResult.error(
          'Permissões de localização permanentemente negadas. Habilite-as manualmente em Configurações > Aplicativos > EcoMapa DF.',
        );
      }

      // 3. Captura a localização com tempo limite de segurança
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );

      return LocationResult.success(position);
    } catch (e) {
      return LocationResult.error(
        'Erro ao conectar ao sensor de GPS: ${e.toString()}',
      );
    }
  }
}
