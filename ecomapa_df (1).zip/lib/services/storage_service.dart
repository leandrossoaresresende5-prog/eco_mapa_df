import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/waste_point.dart';
import '../data/demo_data.dart';

/// Serviço de armazenamento local.
/// Organizado com métodos assíncronos desacoplados para permitir substituição direta
/// por Firebase Firestore ou Cloud SQL sem alterar as telas.
class StorageService {
  static const String _storageKey = 'ecomapa_df_waste_points';

  /// Carrega a lista de pontos salvos.
  /// Se for a primeira vez que o usuário abre o aplicativo, inicializa com dados de demonstração.
  static Future<List<WastePoint>> loadWastePoints() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? jsonString = prefs.getString(_storageKey);

      if (jsonString == null || jsonString.isEmpty) {
        // Inicializa com dados de demonstração de Riacho Fundo I
        final initialList = getInitialDemoPoints();
        await saveWastePoints(initialList);
        return initialList;
      }

      final List<dynamic> decodedList = json.decode(jsonString);
      return decodedList
          .map((item) => WastePoint.fromMap(item as Map<String, dynamic>))
          .toList();
    } catch (e) {
      // Fallback seguro em caso de falha de leitura
      return getInitialDemoPoints();
    }
  }

  /// Salva a lista completa de pontos de descarte no armazenamento local
  static Future<bool> saveWastePoints(List<WastePoint> points) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<Map<String, dynamic>> mapList =
          points.map((p) => p.toMap()).toList();
      final String jsonString = json.encode(mapList);
      return await prefs.setString(_storageKey, jsonString);
    } catch (e) {
      return false;
    }
  }

  /// Adiciona um novo ponto cadastrado à lista existente
  static Future<bool> addWastePoint(WastePoint newPoint) async {
    try {
      final currentList = await loadWastePoints();
      currentList.insert(0, newPoint); // Insere no topo
      return await saveWastePoints(currentList);
    } catch (e) {
      return false;
    }
  }

  /// Exclui um ponto pelo ID
  static Future<bool> deleteWastePoint(String id) async {
    try {
      final currentList = await loadWastePoints();
      currentList.removeWhere((item) => item.id == id);
      return await saveWastePoints(currentList);
    } catch (e) {
      return false;
    }
  }

  /// Restaura os dados originais de demonstração
  static Future<void> resetToDemoData() async {
    await saveWastePoints(getInitialDemoPoints());
  }
}
